# Web

المجلد مخصص لواجهة React + Vite + TailwindCSS.
سيتم إنشاء مشروع الواجهة ومكوناته في مرحلة Web بعد تأسيس Backend وعقد API.
