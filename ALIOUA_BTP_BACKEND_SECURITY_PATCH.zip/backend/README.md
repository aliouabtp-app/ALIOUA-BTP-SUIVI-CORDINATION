# Backend — المرحلة الثانية

تم تجهيز نماذج البيانات وأساس المصادقة JWT ونقاط API التمهيدية. CRUD الكامل وصلاحيات الأدوار التفصيلية سيُستكملان في المهام التالية.

## 1) المتطلبات
- Python 3.11 أو أحدث.
- جميع الحزم في `requirements.txt` مجانية ومفتوحة المصدر.
- لا حاجة إلى بطاقة بنكية.

## 2) إعداد بيئة محلية
من داخل مجلد `backend`:

```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
```

## 3) إنشاء قاعدة البيانات
**مهم:** نموذج المستخدم المخصص موجود منذ البداية. يجب إنشاء وترحيل هذه النماذج قبل إنشاء أي مستخدم أو تشغيل المشروع على قاعدة بيانات قديمة.

```bash
python manage.py makemigrations core
python manage.py migrate
python manage.py check
```

## 4) إنشاء مدير النظام
```bash
python manage.py createsuperuser
```

أدخل البريد الإلكتروني وكلمة المرور والاسم الكامل والدور عند طلبها إذا طلب Django ذلك.

## 5) إنشاء البيانات التجريبية
```bash
python manage.py seed_demo
```

الحسابات التي ينشئها الأمر عند عدم وجودها:
- admin@alioua.local
- manager@alioua.local
- engineer@alioua.local

كلمة المرور الأولية للحسابات الجديدة: `ChangeMe123!`

**تحذير أمني:** بيانات الدخول هذه للتجربة المحلية فقط. غيّرها فوراً، ولا تعرض الخادم للإنترنت بهذه الكلمات أو بمفتاح SECRET_KEY الافتراضي.

## 6) تشغيل لوحة الإدارة
```bash
python manage.py runserver
```
ثم افتح `http://127.0.0.1:8000/admin/`.

## ملاحظات قاعدة البيانات
- SQLite مجانية ومضمنة ولا تحتاج خدمة مستضافة.
- مناسبة للتطوير والاستخدام الداخلي البسيط، وليست الخيار الأفضل لعدد كبير من عمليات الكتابة المتزامنة.
- الصور والمخططات تحفظ محلياً تحت `media/`، ويجب تضمين هذا المجلد في النسخ الاحتياطي.
- لا توجد migrations مولّدة مسبقاً في الحزمة؛ أنشئها بالأمر أعلاه بعد تثبيت Django. هذا مقصود لتوليد migration متوافقة مع إصدار Django المثبت.

## نقاط API المتاحة حالياً

- `GET /api/health/` فحص الخدمة وقاعدة البيانات (عام).
- `POST /api/auth/token/` تسجيل الدخول بالبريد الإلكتروني وكلمة المرور وإرجاع JWT.
- `POST /api/auth/token/refresh/` تجديد رمز الوصول.
- `GET /api/auth/me/` بيانات المستخدم الحالي ودوره (يتطلب `Authorization: Bearer <access>`).
- `GET /api/schema/` مخطط OpenAPI.
- `GET /api/docs/` واجهة Swagger.

إعدادات CORS تقرأ العناوين من `CORS_ALLOWED_ORIGINS` بصيغة عناوين مفصولة بفواصل.
لا تضع `DJANGO_SECRET_KEY` الافتراضي في بيئة الإنتاج، واضبط `DJANGO_DEBUG=0` و`DJANGO_ALLOWED_HOSTS`.
