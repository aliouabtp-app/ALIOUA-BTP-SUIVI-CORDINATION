from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .forms import CustomUserCreationForm, CustomUserChangeForm
from .models import User, Project, Building, Level, Space, Drawing, Issue, Task, Photo, Progress, AuditLog


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    add_form = CustomUserCreationForm
    form = CustomUserChangeForm
    ordering = ("email",)
    list_display = ("email", "full_name", "role", "is_staff", "is_active")
    fieldsets = (
        (None, {"fields": ("email", "password")}),
        ("المعلومات الشخصية", {"fields": ("full_name", "role")}),
        ("الصلاحيات", {"fields": ("is_active", "is_staff", "is_superuser", "groups", "user_permissions")}),
        ("التواريخ", {"fields": ("last_login", "date_joined")}),
    )
    add_fieldsets = (
        (None, {"classes": ("wide",), "fields": ("email", "full_name", "role", "password1", "password2")}),
    )
    search_fields = ("email", "full_name")
    filter_horizontal = ("groups", "user_permissions")
    readonly_fields = ("last_login", "date_joined")


class SoftDeleteAdmin(admin.ModelAdmin):
    list_filter = ("is_deleted",)
    readonly_fields = ("created_at", "updated_at", "deleted_at", "archived_at")


@admin.register(Project)
class ProjectAdmin(SoftDeleteAdmin):
    list_display = ("name", "client", "status", "start_date", "end_date", "is_deleted")
    search_fields = ("name", "client")


@admin.register(Building)
class BuildingAdmin(SoftDeleteAdmin):
    list_display = ("name", "project", "is_deleted")
    search_fields = ("name",)


@admin.register(Level)
class LevelAdmin(SoftDeleteAdmin):
    list_display = ("name", "building", "elevation", "is_deleted")


@admin.register(Space)
class SpaceAdmin(SoftDeleteAdmin):
    list_display = ("name", "level", "space_type", "qr_token", "is_deleted")
    readonly_fields = ("qr_token",)


@admin.register(Drawing)
class DrawingAdmin(SoftDeleteAdmin):
    list_display = ("title", "level", "file_type", "uploaded_by", "created_at")


@admin.register(Issue)
class IssueAdmin(SoftDeleteAdmin):
    list_display = ("title", "space", "priority", "status", "assignee", "due_date")
    list_filter = ("status", "priority")


@admin.register(Task)
class TaskAdmin(SoftDeleteAdmin):
    list_display = ("name", "space", "progress", "status", "assignee", "due_date")
    list_filter = ("status",)


@admin.register(Photo)
class PhotoAdmin(SoftDeleteAdmin):
    list_display = ("original_filename", "space", "issue", "task", "uploaded_by")


@admin.register(Progress)
class ProgressAdmin(admin.ModelAdmin):
    list_display = ("space", "percent", "updated_by", "updated_at")
    readonly_fields = ("created_at", "updated_at")


@admin.register(AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    list_display = ("timestamp", "user", "action", "entity", "entity_id")
    list_filter = ("action", "entity")
    readonly_fields = ("user", "action", "entity", "entity_id", "timestamp", "payload")

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
