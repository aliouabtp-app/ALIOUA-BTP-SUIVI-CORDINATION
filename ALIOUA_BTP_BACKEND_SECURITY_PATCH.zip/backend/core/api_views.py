from django.db import connection, transaction
from django.utils import timezone
from rest_framework import viewsets
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema

from . import models
from .serializers import (
    CurrentUserSerializer, ProjectSerializer, BuildingSerializer, LevelSerializer,
    SpaceSerializer, DrawingSerializer, IssueSerializer, TaskSerializer,
    PhotoSerializer, ProgressSerializer, AuditLogSerializer,
    UserAdminSerializer,
)
from .permissions import RoleBasedPermission, AdminOnlyPermission


class HealthView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []

    @extend_schema(tags=["النظام"], summary="فحص صحة الخادم وقاعدة البيانات")
    def get(self, request):
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            cursor.fetchone()
        return Response({"status": "ok", "database": "ok", "service": "ALIOUA BTP API"})


class CurrentUserView(APIView):
    permission_classes = [IsAuthenticated]

    @extend_schema(tags=["المصادقة"], summary="بيانات المستخدم الحالي", responses=CurrentUserSerializer)
    def get(self, request):
        return Response(CurrentUserSerializer(request.user).data)


class AuditedModelViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated, RoleBasedPermission]
    write_roles = set()
    audit_entity = None
    creator_field = None

    def _create_audit(self, obj, action, fields=None, payload=None):
        """تسجيل العملية داخل المعاملة نفسها حتى لا ينفصل التغيير عن سجل التدقيق."""
        data = payload if payload is not None else {"fields": sorted(fields or [])}
        return models.AuditLog.objects.create(
            user=self.request.user,
            action=action,
            entity=self.audit_entity or obj.__class__.__name__,
            entity_id=obj.pk,
            payload=data,
        )

    def perform_create(self, serializer):
        kwargs = {}
        if self.creator_field:
            kwargs[self.creator_field] = self.request.user
        with transaction.atomic():
            obj = serializer.save(**kwargs)
            self._create_audit(obj, models.AuditLog.Action.CREATE,
                               serializer.validated_data.keys())

    def perform_update(self, serializer):
        with transaction.atomic():
            obj = serializer.save()
            self._create_audit(obj, models.AuditLog.Action.UPDATE,
                               serializer.validated_data.keys())

    def perform_destroy(self, instance):
        # الحذف الناعم يحافظ على البيانات وسجلها بدلاً من الحذف النهائي.
        if not hasattr(instance, "is_deleted"):
            from rest_framework.exceptions import MethodNotAllowed
            raise MethodNotAllowed(
                "DELETE",
                detail="لا يسمح بحذف هذا السجل؛ أنشئ تحديثاً جديداً بدلاً منه.",
            )

        with transaction.atomic():
            instance.is_deleted = True
            instance.deleted_at = timezone.now()
            instance.save(update_fields=["is_deleted", "deleted_at", "updated_at"])
            self._create_audit(instance, models.AuditLog.Action.SOFT_DELETE, payload={})


class ProjectViewSet(AuditedModelViewSet):
    queryset = models.Project.objects.all()
    serializer_class = ProjectSerializer
    write_roles = {"ADMIN", "MANAGER"}
    search_fields = ["name", "client"]
    filterset_fields = ["status"]
    ordering_fields = ["name", "start_date", "end_date", "created_at"]


class BuildingViewSet(AuditedModelViewSet):
    queryset = models.Building.objects.select_related("project")
    serializer_class = BuildingSerializer
    write_roles = {"ADMIN", "MANAGER", "ENGINEER"}
    search_fields = ["name", "project__name"]
    filterset_fields = ["project"]


class LevelViewSet(AuditedModelViewSet):
    queryset = models.Level.objects.select_related("building", "building__project")
    serializer_class = LevelSerializer
    write_roles = {"ADMIN", "MANAGER", "ENGINEER"}
    search_fields = ["name", "building__name"]
    filterset_fields = ["building"]


class SpaceViewSet(AuditedModelViewSet):
    queryset = models.Space.objects.select_related("level", "level__building")
    serializer_class = SpaceSerializer
    write_roles = {"ADMIN", "MANAGER", "ENGINEER"}
    search_fields = ["name"]
    filterset_fields = ["level", "space_type"]


class DrawingViewSet(AuditedModelViewSet):
    queryset = models.Drawing.objects.select_related("level", "uploaded_by")
    serializer_class = DrawingSerializer
    write_roles = {"ADMIN", "MANAGER", "ENGINEER"}
    creator_field = "uploaded_by"
    search_fields = ["title", "original_filename"]
    filterset_fields = ["level", "file_type"]

    def perform_create(self, serializer):
        file_obj = serializer.validated_data.get("file")
        with transaction.atomic():
            obj = serializer.save(
                uploaded_by=self.request.user,
                original_filename=getattr(file_obj, "name", ""),
                file_size=getattr(file_obj, "size", 0),
            )
            self._create_audit(obj, models.AuditLog.Action.CREATE,
                               serializer.validated_data.keys(),
                               payload={"original_filename": getattr(file_obj, "name", ""),
                                        "file_size": getattr(file_obj, "size", 0)})


class IssueViewSet(AuditedModelViewSet):
    queryset = models.Issue.objects.select_related("space", "assignee", "created_by", "drawing")
    serializer_class = IssueSerializer
    write_roles = {"ADMIN", "MANAGER", "ENGINEER", "INSPECTOR"}
    creator_field = "created_by"
    search_fields = ["title", "description", "space__name"]
    filterset_fields = ["status", "priority", "assignee", "space"]
    ordering_fields = ["created_at", "due_date", "priority", "status"]

    def perform_update(self, serializer):
        old_status = serializer.instance.status
        with transaction.atomic():
            obj = serializer.save()
            if obj.status == models.Issue.Status.CLOSED and old_status != models.Issue.Status.CLOSED:
                obj.closed_at = timezone.now()
                obj.save(update_fields=["closed_at", "updated_at"])
            elif obj.status != models.Issue.Status.CLOSED and old_status == models.Issue.Status.CLOSED:
                obj.closed_at = None
                obj.save(update_fields=["closed_at", "updated_at"])
            self._create_audit(obj, models.AuditLog.Action.UPDATE,
                               serializer.validated_data.keys())


class TaskViewSet(AuditedModelViewSet):
    queryset = models.Task.objects.select_related("space", "assignee", "created_by")
    serializer_class = TaskSerializer
    write_roles = {"ADMIN", "MANAGER", "ENGINEER"}
    creator_field = "created_by"
    search_fields = ["name", "description", "space__name"]
    filterset_fields = ["status", "assignee", "space"]
    ordering_fields = ["due_date", "progress", "created_at"]


class PhotoViewSet(AuditedModelViewSet):
    queryset = models.Photo.objects.select_related("issue", "task", "space", "uploaded_by")
    serializer_class = PhotoSerializer
    write_roles = {"ADMIN", "MANAGER", "ENGINEER", "INSPECTOR"}
    creator_field = "uploaded_by"
    search_fields = ["original_filename"]
    filterset_fields = ["issue", "task", "space"]

    def perform_create(self, serializer):
        image = serializer.validated_data["image"]
        with transaction.atomic():
            obj = serializer.save(
                uploaded_by=self.request.user,
                original_filename=image.name,
                file_size=image.size,
            )
            self._create_audit(
                obj,
                models.AuditLog.Action.CREATE,
                payload={"original_filename": image.name, "file_size": image.size},
            )


class ProgressViewSet(AuditedModelViewSet):
    queryset = models.Progress.objects.select_related("space", "updated_by")
    serializer_class = ProgressSerializer
    http_method_names = ["get", "post", "head", "options"]
    write_roles = {"ADMIN", "MANAGER", "ENGINEER"}
    creator_field = "updated_by"
    filterset_fields = ["space"]
    ordering_fields = ["updated_at", "percent"]


class AuditLogViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = models.AuditLog.objects.select_related("user")
    serializer_class = AuditLogSerializer
    # سجل التدقيق إداري وسري: ADMIN فقط.
    permission_classes = [AdminOnlyPermission]
    filterset_fields = ["action", "entity", "user"]
    ordering_fields = ["timestamp"]


class UserViewSet(AuditedModelViewSet):
    """إدارة الحسابات والأدوار: مدير النظام فقط."""

    queryset = models.User.objects.all().order_by("full_name", "email")
    serializer_class = UserAdminSerializer
    permission_classes = [AdminOnlyPermission]
    http_method_names = ["get", "post", "put", "patch", "head", "options"]
    search_fields = ["email", "full_name"]
    filterset_fields = ["role", "is_active"]
    ordering_fields = ["full_name", "email", "date_joined"]
    audit_entity = "User"
