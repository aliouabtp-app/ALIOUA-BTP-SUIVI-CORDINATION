from rest_framework.permissions import BasePermission, SAFE_METHODS


class RoleBasedPermission(BasePermission):
    """
    صلاحيات مركزية حسب دور المستخدم:
    - ADMIN: تحكم كامل.
    - بقية الأدوار: القراءة مسموحة، والكتابة حسب write_roles لكل واجهة.
    """

    message = "ليست لديك الصلاحية اللازمة لتنفيذ هذه العملية."

    def has_permission(self, request, view):
        user = request.user

        # منع المستخدم غير المسجل أو الحساب المعطل
        if not user or not user.is_authenticated or not user.is_active:
            return False

        # مدير النظام وحده يملك صلاحيات الإدارة الكاملة
        if user.is_superuser or user.role == "ADMIN":
            return True

        # القراءة متاحة للمستخدمين النشطين
        if request.method in SAFE_METHODS:
            return True

        # الكتابة لا تتم إلا إذا كان الدور مسموحاً به صراحةً
        allowed_roles = getattr(view, "write_roles", set()) or set()
        return user.role in allowed_roles

    def has_object_permission(self, request, view, obj):
        # تطبيق السياسة نفسها عند الوصول إلى سجل بعينه
        return self.has_permission(request, view)


class AdminOnlyPermission(BasePermission):
    """تقييد العمليات الإدارية الحساسة على ADMIN فقط."""

    message = "هذه العملية متاحة لمدير النظام فقط."

    def has_permission(self, request, view):
        user = request.user
        return bool(
            user
            and user.is_authenticated
            and user.is_active
            and (user.is_superuser or user.role == "ADMIN")
        )

    def has_object_permission(self, request, view, obj):
        return self.has_permission(request, view)
