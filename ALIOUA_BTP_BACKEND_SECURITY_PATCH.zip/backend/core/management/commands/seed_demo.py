from datetime import date, timedelta
from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone

from core.models import User, Project, Building, Level, Space, Issue, Task, Progress


class Command(BaseCommand):
    help = "إنشاء بيانات تجريبية عربية لمشروع ALIOUA BTP"

    @transaction.atomic
    def handle(self, *args, **options):
        # كلمات المرور أدناه للتجربة المحلية فقط ويجب تغييرها قبل أي نشر.
        users_data = [
            ("admin@alioua.local", "مدير النظام", User.Role.ADMIN, "ChangeMe123!"),
            ("manager@alioua.local", "مسير الشركة", User.Role.MANAGER, "ChangeMe123!"),
            ("engineer@alioua.local", "مهندس الموقع", User.Role.ENGINEER, "ChangeMe123!"),
        ]
        users = {}
        for email, full_name, role, password in users_data:
            user, created = User.objects.get_or_create(
                email=email,
                defaults={"full_name": full_name, "role": role, "is_staff": role == User.Role.ADMIN, "is_superuser": role == User.Role.ADMIN},
            )
            if created:
                user.set_password(password)
                user.save()
            users[role] = user

        project, _ = Project.all_objects.get_or_create(
            name="مشروع تجريبي - ALIOUA BTP",
            defaults={"client": "عميل تجريبي", "start_date": date.today(), "status": Project.Status.ACTIVE},
        )
        project.is_deleted = False
        project.save()

        building, _ = Building.all_objects.get_or_create(project=project, name="المبنى الرئيسي")
        building.is_deleted = False
        building.save()

        levels = []
        for idx, name in enumerate(["الطابق الأرضي", "الطابق الأول", "الطابق الثاني"]):
            level, _ = Level.all_objects.get_or_create(building=building, name=name, defaults={"elevation": idx * 3})
            level.is_deleted = False
            level.save()
            levels.append(level)

        spaces = []
        space_specs = [
            (0, "المدخل الرئيسي", Space.SpaceType.OTHER),
            (0, "قاعة الاستقبال", Space.SpaceType.ROOM),
            (1, "المكتب الإداري", Space.SpaceType.OFFICE),
            (1, "الممر الشرقي", Space.SpaceType.CORRIDOR),
            (2, "قاعة الاجتماعات", Space.SpaceType.ROOM),
            (2, "دورات المياه", Space.SpaceType.BATHROOM),
        ]
        for level_idx, name, space_type in space_specs:
            space, _ = Space.all_objects.get_or_create(
                level=levels[level_idx], name=name, defaults={"space_type": space_type}
            )
            space.is_deleted = False
            space.save()
            spaces.append(space)

        issue_specs = [
            ("معالجة تشقق موضعي", Issue.Priority.HIGH, 0),
            ("استكمال دهان الجدار", Issue.Priority.MEDIUM, 1),
            ("مراجعة تثبيت الأبواب", Issue.Priority.MEDIUM, 2),
            ("إصلاح حافة الممر", Issue.Priority.LOW, 3),
            ("فحص إنارة القاعة", Issue.Priority.CRITICAL, 4),
        ]
        engineer = users[User.Role.ENGINEER]
        manager = users[User.Role.MANAGER]
        for title, priority, space_idx in issue_specs:
            Issue.objects.get_or_create(
                space=spaces[space_idx],
                title=title,
                defaults={
                    "description": "ملاحظة تجريبية لاختبار النظام.",
                    "priority": priority,
                    "status": Issue.Status.OPEN,
                    "assignee": engineer,
                    "due_date": date.today() + timedelta(days=5),
                    "created_by": manager,
                },
            )

        task_specs = [
            ("تهيئة منطقة العمل", 100, 0),
            ("إنجاز طبقة الأساس", 75, 1),
            ("تركيب الأبواب", 50, 2),
            ("إنهاء أعمال الممر", 30, 3),
            ("اختبار الإنارة", 0, 4),
        ]
        for name, percent, space_idx in task_specs:
            Task.objects.get_or_create(
                space=spaces[space_idx],
                name=name,
                defaults={
                    "progress": percent,
                    "status": Task.Status.DONE if percent == 100 else (Task.Status.IN_PROGRESS if percent else Task.Status.TODO),
                    "assignee": engineer,
                    "created_by": manager,
                    "due_date": date.today() + timedelta(days=7),
                },
            )

        for idx, space in enumerate(spaces):
            Progress.objects.get_or_create(
                space=space,
                percent=[100, 75, 50, 30, 0, 0][idx],
                defaults={"updated_by": manager, "note": "قيمة تجريبية"},
            )

        self.stdout.write(self.style.SUCCESS(
            "تم تجهيز البيانات التجريبية: مشروع واحد، مبنى واحد، 3 طوابق، 6 مساحات، 5 ملاحظات، 5 مهام، و3 مستخدمين."
        ))
        self.stdout.write("حسابات التجربة: admin@alioua.local / manager@alioua.local / engineer@alioua.local")
        self.stdout.write("كلمة المرور الأولية لكل حساب جديد: ChangeMe123! — غيّرها فوراً ولا تستخدمها في الإنتاج.")
