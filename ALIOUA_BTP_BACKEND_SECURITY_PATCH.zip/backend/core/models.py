import uuid
from decimal import Decimal

from django.conf import settings
from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.core.exceptions import ValidationError
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.db.models import Q


class UUIDModel(models.Model):
    # UUID يجعل إنشاء السجلات محلياً على الهاتف ومزامنتها لاحقاً أسهل.
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    class Meta:
        abstract = True


class TimeStampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class SoftDeleteModel(TimeStampedModel):
    # الحذف الناعم يحافظ على السجلات لأغراض التتبع والتدقيق.
    is_deleted = models.BooleanField(default=False, db_index=True)
    deleted_at = models.DateTimeField(null=True, blank=True)
    archived_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        abstract = True


class UserManager(BaseUserManager):
    use_in_migrations = True

    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError("يجب إدخال البريد الإلكتروني")
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("is_active", True)
        extra_fields.setdefault("role", User.Role.ADMIN)
        if extra_fields.get("is_staff") is not True:
            raise ValueError("يجب أن يكون مدير النظام is_staff=True")
        if extra_fields.get("is_superuser") is not True:
            raise ValueError("يجب أن يكون مدير النظام is_superuser=True")
        return self.create_user(email, password, **extra_fields)


class User(AbstractUser, UUIDModel):
    class Role(models.TextChoices):
        ADMIN = "ADMIN", "مدير النظام"
        MANAGER = "MANAGER", "مسير الشركة"
        ENGINEER = "ENGINEER", "مهندس"
        INSPECTOR = "INSPECTOR", "مراقب"
        VIEWER = "VIEWER", "مشاهد"

    username = None
    email = models.EmailField(unique=True)
    full_name = models.CharField(max_length=160)
    role = models.CharField(max_length=20, choices=Role.choices, default=Role.VIEWER, db_index=True)

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["full_name"]

    objects = UserManager()

    def __str__(self):
        return f"{self.full_name} ({self.email})"


class ActiveManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(is_deleted=False)


class Project(SoftDeleteModel, UUIDModel):
    class Status(models.TextChoices):
        PLANNING = "PLANNING", "قيد التخطيط"
        ACTIVE = "ACTIVE", "نشط"
        ON_HOLD = "ON_HOLD", "متوقف مؤقتاً"
        COMPLETED = "COMPLETED", "مكتمل"
        CANCELLED = "CANCELLED", "ملغى"

    name = models.CharField(max_length=200)
    client = models.CharField(max_length=200, blank=True)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PLANNING, db_index=True)

    objects = ActiveManager()
    all_objects = models.Manager()

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class Building(SoftDeleteModel, UUIDModel):
    project = models.ForeignKey(Project, on_delete=models.PROTECT, related_name="buildings")
    name = models.CharField(max_length=160)

    objects = ActiveManager()
    all_objects = models.Manager()

    class Meta:
        ordering = ["name"]
        constraints = [
            models.UniqueConstraint(fields=["project", "name"], condition=Q(is_deleted=False), name="uq_active_building_project_name")
        ]

    def __str__(self):
        return f"{self.project.name} / {self.name}"


class Level(SoftDeleteModel, UUIDModel):
    building = models.ForeignKey(Building, on_delete=models.PROTECT, related_name="levels")
    name = models.CharField(max_length=120)
    elevation = models.DecimalField(max_digits=8, decimal_places=3, null=True, blank=True, help_text="المنسوب بالمتر")

    objects = ActiveManager()
    all_objects = models.Manager()

    class Meta:
        ordering = ["name"]
        constraints = [
            models.UniqueConstraint(fields=["building", "name"], condition=Q(is_deleted=False), name="uq_active_level_building_name")
        ]

    def __str__(self):
        return f"{self.building.name} / {self.name}"


class Space(SoftDeleteModel, UUIDModel):
    class SpaceType(models.TextChoices):
        ROOM = "ROOM", "غرفة"
        CORRIDOR = "CORRIDOR", "ممر"
        OFFICE = "OFFICE", "مكتب"
        BATHROOM = "BATHROOM", "حمام"
        EXTERNAL = "EXTERNAL", "مساحة خارجية"
        OTHER = "OTHER", "أخرى"

    level = models.ForeignKey(Level, on_delete=models.PROTECT, related_name="spaces")
    name = models.CharField(max_length=160)
    space_type = models.CharField(max_length=20, choices=SpaceType.choices, default=SpaceType.OTHER)
    qr_token = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)

    objects = ActiveManager()
    all_objects = models.Manager()

    class Meta:
        ordering = ["name"]
        constraints = [
            models.UniqueConstraint(fields=["level", "name"], condition=Q(is_deleted=False), name="uq_active_space_level_name")
        ]

    def __str__(self):
        return f"{self.level.name} / {self.name}"


class Drawing(SoftDeleteModel, UUIDModel):
    class FileType(models.TextChoices):
        PDF = "PDF", "PDF"
        IMAGE = "IMAGE", "صورة"

    level = models.ForeignKey(Level, on_delete=models.PROTECT, related_name="drawings")
    title = models.CharField(max_length=200)
    file = models.FileField(upload_to="drawings/%Y/%m/")
    file_type = models.CharField(max_length=10, choices=FileType.choices)
    original_filename = models.CharField(max_length=255, blank=True)
    file_size = models.PositiveBigIntegerField(default=0)
    uploaded_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="uploaded_drawings")

    objects = ActiveManager()
    all_objects = models.Manager()

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.title


class Issue(SoftDeleteModel, UUIDModel):
    class Priority(models.TextChoices):
        LOW = "LOW", "منخفضة"
        MEDIUM = "MEDIUM", "متوسطة"
        HIGH = "HIGH", "مرتفعة"
        CRITICAL = "CRITICAL", "حرجة"

    class Status(models.TextChoices):
        OPEN = "OPEN", "مفتوحة"
        IN_PROGRESS = "IN_PROGRESS", "قيد المعالجة"
        CLOSED = "CLOSED", "مغلقة"

    space = models.ForeignKey(Space, on_delete=models.PROTECT, related_name="issues")
    title = models.CharField(max_length=220)
    description = models.TextField(blank=True)
    priority = models.CharField(max_length=12, choices=Priority.choices, default=Priority.MEDIUM, db_index=True)
    status = models.CharField(max_length=15, choices=Status.choices, default=Status.OPEN, db_index=True)
    assignee = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="assigned_issues")
    due_date = models.DateField(null=True, blank=True, db_index=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="created_issues")
    closed_at = models.DateTimeField(null=True, blank=True)
    drawing = models.ForeignKey(Drawing, on_delete=models.SET_NULL, null=True, blank=True, related_name="issues")
    # إحداثيات نسبية من 0 إلى 1 لتحديد مكان الملاحظة على المخطط.
    pin_x = models.DecimalField(max_digits=7, decimal_places=6, null=True, blank=True, validators=[MinValueValidator(Decimal("0")), MaxValueValidator(Decimal("1"))])
    pin_y = models.DecimalField(max_digits=7, decimal_places=6, null=True, blank=True, validators=[MinValueValidator(Decimal("0")), MaxValueValidator(Decimal("1"))])

    objects = ActiveManager()
    all_objects = models.Manager()

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["status", "due_date"], name="issue_status_due_idx"),
            models.Index(fields=["space", "created_at"], name="issue_space_created_idx"),
        ]

    def clean(self):
        super().clean()
        if (self.pin_x is None) != (self.pin_y is None):
            raise ValidationError("يجب إدخال إحداثيي النقطة معاً أو تركهما فارغين.")
        if (self.pin_x is not None or self.pin_y is not None) and not self.drawing_id:
            raise ValidationError("يجب تحديد المخطط عند تحديد موقع الملاحظة عليه.")

    def __str__(self):
        return self.title


class Task(SoftDeleteModel, UUIDModel):
    class Status(models.TextChoices):
        TODO = "TODO", "لم تبدأ"
        IN_PROGRESS = "IN_PROGRESS", "قيد الإنجاز"
        DONE = "DONE", "منجزة"
        BLOCKED = "BLOCKED", "متعذرة"

    space = models.ForeignKey(Space, on_delete=models.PROTECT, related_name="tasks")
    name = models.CharField(max_length=220)
    description = models.TextField(blank=True)
    progress = models.PositiveSmallIntegerField(default=0, validators=[MinValueValidator(0), MaxValueValidator(100)])
    status = models.CharField(max_length=15, choices=Status.choices, default=Status.TODO, db_index=True)
    assignee = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="assigned_tasks")
    due_date = models.DateField(null=True, blank=True, db_index=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True, related_name="created_tasks")

    objects = ActiveManager()
    all_objects = models.Manager()

    class Meta:
        ordering = ["due_date", "name"]
        indexes = [models.Index(fields=["space", "status"], name="task_space_status_idx")]

    def __str__(self):
        return self.name


class Photo(SoftDeleteModel, UUIDModel):
    issue = models.ForeignKey(Issue, on_delete=models.CASCADE, null=True, blank=True, related_name="photos")
    task = models.ForeignKey(Task, on_delete=models.CASCADE, null=True, blank=True, related_name="photos")
    space = models.ForeignKey(Space, on_delete=models.CASCADE, null=True, blank=True, related_name="photos")
    image = models.ImageField(upload_to="photos/%Y/%m/")
    uploaded_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="uploaded_photos")
    original_filename = models.CharField(max_length=255, blank=True)
    file_size = models.PositiveBigIntegerField(default=0)

    objects = ActiveManager()
    all_objects = models.Manager()

    class Meta:
        ordering = ["-created_at"]

    def clean(self):
        super().clean()

        # يجب أن ترتبط الصورة بسجل واحد فقط.
        links_count = sum((
            self.issue_id is not None,
            self.task_id is not None,
            self.space_id is not None,
        ))

        if links_count != 1:
            raise ValidationError(
                "يجب ربط الصورة بسجل واحد فقط: ملاحظة أو مهمة أو مساحة."
            )

    def __str__(self):
        return self.original_filename or f"صورة {self.pk}"


class Progress( TimeStampedModel, UUIDModel):
    space = models.ForeignKey(Space, on_delete=models.PROTECT, related_name="progress_records")
    percent = models.PositiveSmallIntegerField(validators=[MinValueValidator(0), MaxValueValidator(100)])
    updated_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="progress_updates")
    note = models.CharField(max_length=250, blank=True)

    class Meta:
        ordering = ["-updated_at"]
        indexes = [models.Index(fields=["space", "-updated_at"], name="progress_space_date_idx")]

    def __str__(self):
        return f"{self.space.name}: {self.percent}%"


class AuditLog(UUIDModel):
    class Action(models.TextChoices):
        CREATE = "CREATE", "إنشاء"
        UPDATE = "UPDATE", "تعديل"
        SOFT_DELETE = "SOFT_DELETE", "حذف ناعم"
        RESTORE = "RESTORE", "استعادة"
        ARCHIVE = "ARCHIVE", "أرشفة"
        LOGIN = "LOGIN", "تسجيل دخول"
        OTHER = "OTHER", "أخرى"

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="audit_logs")
    action = models.CharField(max_length=20, choices=Action.choices)
    entity = models.CharField(max_length=80, db_index=True)
    entity_id = models.UUIDField(db_index=True)
    timestamp = models.DateTimeField(auto_now_add=True, db_index=True)
    payload = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ["-timestamp"]
        indexes = [models.Index(fields=["entity", "entity_id", "timestamp"], name="audit_entity_time_idx")]

    def __str__(self):
        return f"{self.action} - {self.entity} - {self.entity_id}"
