
from pathlib import Path
from datetime import timedelta
import os
from dotenv import load_dotenv

from django.core.exceptions import ImproperlyConfigured


# المسار الأساسي لمجلد Backend
BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / '.env')


# ==================================================
# 1. الأمان والإعدادات العامة
# ==================================================

SECRET_KEY = os.getenv("DJANGO_SECRET_KEY", "").strip()

# لا نسمح بمفتاح مفقود أو ضعيف حتى في وضع التطوير
if len(SECRET_KEY) < 50:
    raise ImproperlyConfigured(
        "DJANGO_SECRET_KEY مفقود أو ضعيف؛ تحقق من ملف .env."
    )

DEBUG = os.getenv("DJANGO_DEBUG", "1") == "1"

ALLOWED_HOSTS = [
    host.strip()
    for host in os.getenv(
        "DJANGO_ALLOWED_HOSTS",
        "127.0.0.1,localhost"
    ).split(",")
    if host.strip()
]


# ==================================================
# 2. التطبيقات
# ==================================================

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",

    # CORS
    "corsheaders",

    # REST API
    "rest_framework",
    "django_filters",
    "drf_spectacular",

    # التطبيق الأساسي
    "core",
]


# ==================================================
# 3. Middleware
# ==================================================

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.locale.LocaleMiddleware",

    # يجب أن يسبق CommonMiddleware
    "corsheaders.middleware.CorsMiddleware",

    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]


ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"
ASGI_APPLICATION = "config.asgi.application"


# ==================================================
# 4. قاعدة البيانات SQLite
# ==================================================

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",
        "OPTIONS": {
            "timeout": 20,
        },
    }
}


# ==================================================
# 5. المستخدمون وكلمات المرور
# ==================================================

AUTH_USER_MODEL = "core.User"

AUTH_PASSWORD_VALIDATORS = [
    {
        "NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"
    },
    {
        "NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"
    },
    {
        "NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"
    },
    {
        "NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"
    },
]


# ==================================================
# 6. اللغة والتوقيت
# ==================================================

LANGUAGE_CODE = "ar"

LANGUAGES = [
    ("ar", "العربية"),
    ("fr", "Français"),
]

TIME_ZONE = "Africa/Casablanca"

USE_I18N = True
USE_TZ = True


# ==================================================
# 7. الملفات والصور
# ==================================================

STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / "staticfiles"

MEDIA_URL = "media/"
MEDIA_ROOT = BASE_DIR / "media"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"


# ==================================================
# 8. إعدادات CORS
# ==================================================

CORS_ALLOWED_ORIGINS = [
    origin.strip()
    for origin in os.getenv(
        "CORS_ALLOWED_ORIGINS",
        "http://localhost:5173"
    ).split(",")
    if origin.strip()
]

# الواجهة تستخدم JWT عبر Authorization Header،
# لذلك لا تحتاج إلى إرسال Cookies مع الطلبات.
CORS_ALLOW_CREDENTIALS = False

CSRF_TRUSTED_ORIGINS = [
    origin.strip()
    for origin in os.getenv(
        "CSRF_TRUSTED_ORIGINS",
        ""
    ).split(",")
    if origin.strip()
]


# ==================================================
# 9. إعدادات Django REST Framework
# ==================================================

REST_FRAMEWORK = {
    "DEFAULT_SCHEMA_CLASS": "drf_spectacular.openapi.AutoSchema",

    "DEFAULT_PERMISSION_CLASSES": [
        "rest_framework.permissions.IsAuthenticated",
    ],

    "DEFAULT_AUTHENTICATION_CLASSES": [
        "rest_framework_simplejwt.authentication.JWTAuthentication",
    ],

    "DEFAULT_FILTER_BACKENDS": [
        "django_filters.rest_framework.DjangoFilterBackend",
        "rest_framework.filters.SearchFilter",
        "rest_framework.filters.OrderingFilter",
    ],

    "DEFAULT_PAGINATION_CLASS": (
        "rest_framework.pagination.PageNumberPagination"
    ),

    "PAGE_SIZE": 20,
}


# ==================================================
# 10. JWT Authentication
# ==================================================

SIMPLE_JWT = {
    "ACCESS_TOKEN_LIFETIME": timedelta(minutes=30),
    "REFRESH_TOKEN_LIFETIME": timedelta(days=7),

    "ROTATE_REFRESH_TOKENS": True,

    # لا يتم تفعيل Blacklist ما دام تطبيق blacklist
    # غير مضاف إلى INSTALLED_APPS.
    "BLACKLIST_AFTER_ROTATION": False,

    "AUTH_HEADER_TYPES": ("Bearer",),

    "UPDATE_LAST_LOGIN": True,
}


# ==================================================
# 11. توثيق OpenAPI / Swagger
# ==================================================

SPECTACULAR_SETTINGS = {
    "TITLE": "ALIOUA BTP MANAGEMENT API",
    "DESCRIPTION": (
        "واجهة API لإدارة المشاريع والمباني والطوابق "
        "والمساحات والملاحظات والمهام والتقدم."
    ),
    "VERSION": "0.2.0",
    "SERVE_INCLUDE_SCHEMA": False,

    "COMPONENTS": {
        "securitySchemes": {
            "BearerAuth": {
                "type": "http",
                "scheme": "bearer",
                "bearerFormat": "JWT",
            }
        }
    },

    "SECURITY": [
        {
            "BearerAuth": []
        }
    ],
}


# ==================================================
# 12. إعدادات الأمان للإنتاج HTTPS
# ==================================================

if not DEBUG:
    SECURE_CONTENT_TYPE_NOSNIFF = True

    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True

    # دعم HTTPS خلف Reverse Proxy مثل Render
    SECURE_PROXY_SSL_HEADER = (
        "HTTP_X_FORWARDED_PROTO",
        "https"
    )

    SECURE_SSL_REDIRECT = (
        os.getenv("DJANGO_SECURE_SSL_REDIRECT", "1") == "1"
    )

