
from django.contrib import admin
from django.urls import path, include

from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)

from drf_spectacular.views import (
    SpectacularAPIView,
    SpectacularSwaggerView,
)

from core.api_views import (
    HealthView,
    CurrentUserView,
    ProjectViewSet,
    BuildingViewSet,
    LevelViewSet,
    SpaceViewSet,
    DrawingViewSet,
    IssueViewSet,
    TaskViewSet,
    PhotoViewSet,
    ProgressViewSet,
    AuditLogViewSet,
    UserViewSet,
)


# تسجيل واجهات إدارة البيانات
router = DefaultRouter()

router.register("projects", ProjectViewSet, basename="project")
router.register("buildings", BuildingViewSet, basename="building")
router.register("levels", LevelViewSet, basename="level")
router.register("spaces", SpaceViewSet, basename="space")
router.register("drawings", DrawingViewSet, basename="drawing")
router.register("issues", IssueViewSet, basename="issue")
router.register("tasks", TaskViewSet, basename="task")
router.register("photos", PhotoViewSet, basename="photo")
router.register("progress", ProgressViewSet, basename="progress")
router.register("audit-logs", AuditLogViewSet, basename="audit-log")
router.register("users", UserViewSet, basename="user")


urlpatterns = [
    # لوحة الإدارة
    path("admin/", admin.site.urls),

    # فحص حالة الخادم
    path("api/health/", HealthView.as_view(), name="health"),

    # المصادقة باستخدام JWT
    path(
        "api/auth/token/",
        TokenObtainPairView.as_view(),
        name="token_obtain_pair",
    ),
    path(
        "api/auth/token/refresh/",
        TokenRefreshView.as_view(),
        name="token_refresh",
    ),

    # بيانات المستخدم الحالي
    path(
        "api/auth/me/",
        CurrentUserView.as_view(),
        name="current_user",
    ),

    # جميع واجهات إدارة المشروع
    path("api/", include(router.urls)),

    # مخطط OpenAPI
    path(
        "api/schema/",
        SpectacularAPIView.as_view(),
        name="schema",
    ),

    # واجهة Swagger
    path(
        "api/docs/",
        SpectacularSwaggerView.as_view(url_name="schema"),
        name="swagger-ui",
    ),
]

