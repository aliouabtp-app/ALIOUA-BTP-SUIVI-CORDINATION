# مصفوفة صلاحيات API الأولية

| المورد | ADMIN | MANAGER | ENGINEER | INSPECTOR | VIEWER |
|---|---|---|---|---|---|
| Projects | CRUD | CRUD | قراءة | قراءة | قراءة |
| Buildings / Levels / Spaces | CRUD | CRUD | CRUD | قراءة | قراءة |
| Drawings | CRUD | CRUD | CRUD | قراءة | قراءة |
| Issues | CRUD | CRUD | CRUD | CRUD | قراءة |
| Tasks | CRUD | CRUD | CRUD | قراءة | قراءة |
| Photos | CRUD | CRUD | CRUD | CRUD | قراءة |
| Progress | إنشاء وقراءة | إنشاء وقراءة | إنشاء وقراءة | قراءة | قراءة |
| Audit logs | قراءة | قراءة | قراءة | قراءة | قراءة |

ملاحظة: الحروف CRUD تعني إنشاء وقراءة وتعديل وحذف (ناعم عند دعم النموذج). لا توجد إدارة مستخدمين عبر API في هذه النسخة. سجل التدقيق للقراءة فقط.
