from django.test import TestCase
from django.core.exceptions import ValidationError
from .models import Project, Building, Level, Space, Issue, User


class CoreModelTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            email="test@example.local", password="StrongTestPass123!",
            full_name="مستخدم اختبار", role=User.Role.ENGINEER
        )
        self.project = Project.objects.create(name="مشروع اختبار")
        self.building = Building.objects.create(project=self.project, name="مبنى الاختبار")
        self.level = Level.objects.create(building=self.building, name="الطابق الأرضي")
        self.space = Space.objects.create(level=self.level, name="المساحة 01")

    def test_space_has_unique_qr_token(self):
        other = Space.objects.create(level=self.level, name="المساحة 02")
        self.assertNotEqual(self.space.qr_token, other.qr_token)

    def test_issue_pin_requires_both_coordinates(self):
        issue = Issue(
            space=self.space, title="اختبار نقطة", created_by=self.user,
            pin_x="0.5", pin_y=None
        )
        with self.assertRaises(ValidationError):
            issue.full_clean()


from rest_framework.test import APITestCase
from rest_framework import status
from django.urls import reverse


class APIFoundationTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            email="api-test@example.local",
            password="StrongTestPass123!",
            full_name="مستخدم API",
            role=User.Role.ENGINEER,
        )

    def test_health_endpoint_is_public(self):
        response = self.client.get("/api/health/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["status"], "ok")

    def test_jwt_login_uses_email(self):
        response = self.client.post(
            "/api/auth/token/",
            {"email": "api-test@example.local", "password": "StrongTestPass123!"},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("access", response.data)
        self.assertIn("refresh", response.data)

    def test_current_user_requires_authentication(self):
        response = self.client.get("/api/auth/me/")
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_current_user_returns_role_with_jwt(self):
        login = self.client.post(
            "/api/auth/token/",
            {"email": "api-test@example.local", "password": "StrongTestPass123!"},
            format="json",
        )
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {login.data['access']}")
        response = self.client.get("/api/auth/me/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["role"], User.Role.ENGINEER)


class SecurityPermissionTests(APITestCase):
    """اختبارات حماية إدارة المستخدمين وسجل التدقيق."""

    def setUp(self):
        self.admin = User.objects.create_user(
            email="security-admin@example.local",
            password="StrongAdminPass123!",
            full_name="مدير النظام",
            role=User.Role.ADMIN,
        )

        self.non_admin_users = []
        for role in (
            User.Role.MANAGER,
            User.Role.ENGINEER,
            User.Role.INSPECTOR,
            User.Role.VIEWER,
        ):
            self.non_admin_users.append(
                User.objects.create_user(
                    email=f"{role.lower()}@example.local",
                    password="StrongTestPass123!",
                    full_name=f"مستخدم {role}",
                    role=role,
                )
            )

    def test_only_admin_can_access_users_and_audit_logs(self):
        for user in self.non_admin_users:
            with self.subTest(role=user.role):
                self.client.force_authenticate(user=user)

                users_response = self.client.get("/api/users/")
                audit_response = self.client.get("/api/audit-logs/")

                self.assertEqual(users_response.status_code, 403)
                self.assertEqual(audit_response.status_code, 403)

    def test_admin_can_create_user_with_hashed_password(self):
        self.client.force_authenticate(user=self.admin)

        response = self.client.post(
            "/api/users/",
            {
                "email": "new-engineer@example.local",
                "full_name": "مهندس جديد",
                "role": User.Role.ENGINEER,
                "password": "NewStrongPass123!",
                "is_superuser": True,
                "is_staff": True,
            },
            format="json",
        )

        self.assertEqual(response.status_code, 201)
        self.assertNotIn("password", response.data)

        created = User.objects.get(email="new-engineer@example.local")
        self.assertTrue(created.check_password("NewStrongPass123!"))
        self.assertFalse(created.is_superuser)
        self.assertFalse(created.is_staff)
        self.assertEqual(created.role, User.Role.ENGINEER)

    def test_admin_can_read_audit_logs(self):
        self.client.force_authenticate(user=self.admin)

        response = self.client.get("/api/audit-logs/")

        self.assertEqual(response.status_code, 200)
