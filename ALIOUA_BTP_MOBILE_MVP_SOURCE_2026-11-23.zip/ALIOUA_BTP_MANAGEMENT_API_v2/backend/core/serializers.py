from pathlib import Path
from PIL import Image, UnidentifiedImageError
from rest_framework import serializers
from . import models


class CurrentUserSerializer(serializers.ModelSerializer):
    """بيانات المستخدم الحالي دون كشف معلومات حساسة."""
    class Meta:
        model = models.User
        fields = ("id", "email", "full_name", "role", "is_active")
        read_only_fields = fields


class SafeModelSerializer(serializers.ModelSerializer):
    """قاعدة مشتركة تمنع تعديل حقول التدقيق والتوقيت من العميل."""
    class Meta:
        fields = "__all__"
        read_only_fields = ("id", "created_at", "updated_at", "is_deleted", "deleted_at", "archived_at")


class ProjectSerializer(SafeModelSerializer):
    class Meta(SafeModelSerializer.Meta):
        model = models.Project


class BuildingSerializer(SafeModelSerializer):
    class Meta(SafeModelSerializer.Meta):
        model = models.Building


class LevelSerializer(SafeModelSerializer):
    class Meta(SafeModelSerializer.Meta):
        model = models.Level


class SpaceSerializer(SafeModelSerializer):
    class Meta(SafeModelSerializer.Meta):
        model = models.Space
        read_only_fields = SafeModelSerializer.Meta.read_only_fields + ("qr_token",)


class DrawingSerializer(SafeModelSerializer):
    class Meta(SafeModelSerializer.Meta):
        model = models.Drawing
        read_only_fields = SafeModelSerializer.Meta.read_only_fields + ("uploaded_by", "original_filename", "file_size")

    def validate_file(self, value):
        suffix = Path(value.name).suffix.lower()
        if suffix not in {".pdf", ".png", ".jpg", ".jpeg", ".webp"}:
            raise serializers.ValidationError("يسمح فقط بملفات PDF و PNG و JPG و WEBP.")
        if value.size > 20 * 1024 * 1024:
            raise serializers.ValidationError("الحد الأقصى لحجم المخطط 20 ميغابايت.")
        return value

    def validate(self, attrs):
        file_value = attrs.get("file", getattr(self.instance, "file", None))
        if file_value:
            suffix = Path(file_value.name).suffix.lower()
            inferred = "PDF" if suffix == ".pdf" else "IMAGE"
            provided = attrs.get("file_type", getattr(self.instance, "file_type", inferred))
            if provided != inferred:
                raise serializers.ValidationError({"file_type": "نوع الملف لا يطابق امتداده."})
        return attrs


class IssueSerializer(SafeModelSerializer):
    class Meta(SafeModelSerializer.Meta):
        model = models.Issue
        read_only_fields = SafeModelSerializer.Meta.read_only_fields + ("created_by", "closed_at")

    def validate(self, attrs):
        space = attrs.get("space", getattr(self.instance, "space", None))
        drawing = attrs.get("drawing", getattr(self.instance, "drawing", None))
        x = attrs.get("pin_x", getattr(self.instance, "pin_x", None))
        y = attrs.get("pin_y", getattr(self.instance, "pin_y", None))
        if (x is None) != (y is None):
            raise serializers.ValidationError("يجب إدخال إحداثيي النقطة معاً.")
        if (x is not None or y is not None) and drawing is None:
            raise serializers.ValidationError({"drawing": "حدد مخطط الطابق قبل وضع النقطة."})
        if drawing and space and drawing.level_id != space.level_id:
            raise serializers.ValidationError({"drawing": "المخطط يجب أن يتبع طابق المساحة نفسها."})
        return attrs


class TaskSerializer(SafeModelSerializer):
    class Meta(SafeModelSerializer.Meta):
        model = models.Task
        read_only_fields = SafeModelSerializer.Meta.read_only_fields + ("created_by",)

    def validate(self, attrs):
        progress = attrs.get("progress", getattr(self.instance, "progress", 0))
        status = attrs.get("status", getattr(self.instance, "status", models.Task.Status.TODO))
        if status == models.Task.Status.DONE and progress != 100:
            raise serializers.ValidationError({"progress": "المهمة المنجزة يجب أن تكون نسبة إنجازها 100%."})
        if progress == 100 and status != models.Task.Status.DONE:
            raise serializers.ValidationError({"status": "عند بلوغ 100% يجب أن تكون المهمة منجزة."})
        return attrs


class PhotoSerializer(SafeModelSerializer):
    class Meta(SafeModelSerializer.Meta):
        model = models.Photo
        read_only_fields = SafeModelSerializer.Meta.read_only_fields + ("uploaded_by", "original_filename", "file_size")

    def validate_image(self, value):
        # الحد الأقصى لحجم الصورة هو 10 ميغابايت.
        if value.size > 10 * 1024 * 1024:
            raise serializers.ValidationError("الحد الأقصى لحجم الصورة 10 ميغابايت.")

        # التحقق من الامتداد ومحتوى الصورة الفعلي باستخدام Pillow.
        suffix = Path(value.name).suffix.lower()
        formats = {".jpg": "JPEG", ".jpeg": "JPEG", ".png": "PNG", ".webp": "WEBP"}
        if suffix not in formats:
            raise serializers.ValidationError("صيغة الصورة غير مدعومة.")

        try:
            value.seek(0)
            with Image.open(value) as img:
                actual_format = img.format
                img.verify()
            value.seek(0)
        except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError):
            value.seek(0)
            raise serializers.ValidationError("الملف ليس صورة سليمة أو أن محتواه تالف.")

        if actual_format != formats[suffix]:
            raise serializers.ValidationError("محتوى الصورة لا يطابق امتداد الملف.")

        return value

    def validate(self, attrs):
        # عند التعديل، نحافظ على الارتباط الحالي إذا لم يُرسل المستخدم حقلاً جديداً.
        issue = attrs.get("issue", self.instance.issue if self.instance else None)
        task = attrs.get("task", self.instance.task if self.instance else None)
        space = attrs.get("space", self.instance.space if self.instance else None)

        links_count = sum((issue is not None, task is not None, space is not None))

        if links_count != 1:
            raise serializers.ValidationError(
                "يجب ربط الصورة بسجل واحد فقط: ملاحظة أو مهمة أو مساحة."
            )

        return attrs


class ProgressSerializer(SafeModelSerializer):
    class Meta(SafeModelSerializer.Meta):
        model = models.Progress
        read_only_fields = ("id", "created_at", "updated_at", "updated_by")


class AuditLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.AuditLog
        fields = "__all__"
        read_only_fields = fields


class UserAdminSerializer(serializers.ModelSerializer):
    """إدارة المستخدمين؛ كلمة المرور لا تُعرض مطلقاً."""

    password = serializers.CharField(
        write_only=True,
        required=False,
        min_length=10,
        trim_whitespace=False,
    )

    class Meta:
        model = models.User
        fields = (
            "id", "email", "full_name", "role", "is_active",
            "password", "last_login", "date_joined",
        )
        read_only_fields = ("id", "last_login", "date_joined")

    def validate(self, attrs):
        if self.instance is None and not attrs.get("password"):
            raise serializers.ValidationError({
                "password": "كلمة المرور مطلوبة عند إنشاء مستخدم جديد."
            })
        return attrs

    def create(self, validated_data):
        password = validated_data.pop("password")
        return models.User.objects.create_user(
            password=password,
            **validated_data,
        )

    def update(self, instance, validated_data):
        password = validated_data.pop("password", None)

        for field, value in validated_data.items():
            setattr(instance, field, value)

        if password:
            instance.set_password(password)

        instance.save()
        return instance
