@echo off
setlocal
cd /d "%~dp0"
where flutter >nul 2>nul || (echo Flutter SDK غير مثبت. ثبّت Flutter أولاً من flutter.dev & exit /b 1)
flutter pub get || exit /b 1
if not exist android\app\src\main\AndroidManifest.xml flutter create . --platforms=android
if errorlevel 1 exit /b 1
python -c "from pathlib import Path; p=Path('android/app/src/main/AndroidManifest.xml'); s=p.read_text(); marker='<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\">'; perms='\n    <uses-permission android:name=\"android.permission.INTERNET\" />\n    <uses-permission android:name=\"android.permission.CAMERA\" />'; s=s if 'android.permission.INTERNET' in s else s.replace(marker,marker+perms); s=s if 'android:usesCleartextTraffic' in s else s.replace('<application','<application android:usesCleartextTraffic=\"true\"',1); p.write_text(s)" || exit /b 1
flutter analyze || exit /b 1
flutter build apk --release || exit /b 1
if not exist dist mkdir dist
copy /Y build\app\outputs\flutter-apk\app-release.apk dist\ALIOUA_BTP.apk
if errorlevel 1 exit /b 1
echo APK: mobile\dist\ALIOUA_BTP.apk
