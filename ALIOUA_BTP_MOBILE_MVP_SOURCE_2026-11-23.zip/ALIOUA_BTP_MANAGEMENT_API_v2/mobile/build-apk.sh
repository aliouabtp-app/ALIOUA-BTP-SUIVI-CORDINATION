#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v flutter >/dev/null 2>&1 || { echo 'Flutter SDK غير مثبت. ثبّت Flutter أولاً من flutter.dev'; exit 1; }
flutter pub get
if [ ! -f android/app/src/main/AndroidManifest.xml ]; then
  flutter create . --platforms=android
fi
# اتصال HTTP مسموح فقط لتسهيل خادم الاختبار داخل شبكة الشركة؛ استخدم HTTPS خارجياً.
python3 - <<'PY'
from pathlib import Path
p=Path('android/app/src/main/AndroidManifest.xml')
s=p.read_text()
marker='<manifest xmlns:android="http://schemas.android.com/apk/res/android">'
if 'android.permission.INTERNET' not in s:
    s=s.replace(marker, marker + '\n    <uses-permission android:name="android.permission.INTERNET" />\n    <uses-permission android:name="android.permission.CAMERA" />')
if 'android:usesCleartextTraffic' not in s:
    s=s.replace('<application', '<application android:usesCleartextTraffic="true"', 1)
p.write_text(s)
PY
flutter analyze
flutter build apk --release
mkdir -p dist
cp build/app/outputs/flutter-apk/app-release.apk dist/ALIOUA_BTP.apk
echo 'APK: mobile/dist/ALIOUA_BTP.apk'
