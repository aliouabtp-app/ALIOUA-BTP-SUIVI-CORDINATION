import 'dart:io';
import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

const brandNavy = Color(0xFF173B63);
const brandTeal = Color(0xFF16A6A1);
const brandGold = Color(0xFFF2B544);
const pageBg = Color(0xFFF4F8FA);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await LocalStore.instance.init();
  runApp(const AliouaApp());
}

class AliouaApp extends StatelessWidget {
  const AliouaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'ALIOUA BTP',
    theme: ThemeData(useMaterial3: true, scaffoldBackgroundColor: pageBg,
      colorScheme: ColorScheme.fromSeed(seedColor: brandTeal, primary: brandNavy),
      appBarTheme: const AppBarTheme(backgroundColor: pageBg, foregroundColor: brandNavy, elevation: 0),
      inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15)),
      elevatedButtonTheme: ElevatedButtonThemeData(style: ElevatedButton.styleFrom(
        backgroundColor: brandNavy, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 15),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))))),
    builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child ?? const SizedBox.shrink()),
    home: const Gate(),
  );
}

class LocalStore {
  LocalStore._(); static final instance = LocalStore._(); late Database db;
  Future<void> init() async {
    final dir = await getDatabasesPath();
    db = await openDatabase(p.join(dir, 'alioua_btp.db'), version: 3,
      onCreate: (d, v) async {
        await d.execute("CREATE TABLE issues(local_id TEXT PRIMARY KEY, server_id TEXT, space_id TEXT NOT NULL, title TEXT NOT NULL, description TEXT, priority TEXT, status TEXT, due_date TEXT, photo_path TEXT, sync_state TEXT NOT NULL, photo_sync_state TEXT NOT NULL DEFAULT 'none', created_at TEXT NOT NULL)");
        await d.execute("CREATE TABLE spaces(id TEXT PRIMARY KEY, name TEXT NOT NULL, level_name TEXT)");
      },
      onUpgrade: (d, oldVersion, newVersion) async {
        // ترقية قاعدة الهاتف دون حذف الملاحظات المحفوظة سابقاً.
        if (oldVersion < 2) {
          await d.execute("CREATE TABLE IF NOT EXISTS spaces(id TEXT PRIMARY KEY, name TEXT NOT NULL, level_name TEXT)");
        }
        if (oldVersion < 3) {
          await d.execute("ALTER TABLE issues ADD COLUMN photo_sync_state TEXT NOT NULL DEFAULT 'none'");
        }
      });
  }
  Future<List<Map<String,dynamic>>> issues() => db.query('issues', orderBy:'created_at DESC');
  Future<List<Map<String,dynamic>>> spaces() => db.query('spaces', orderBy:'name');
  Future<void> saveIssue(Map<String,dynamic> row) async => db.insert('issues', row, conflictAlgorithm: ConflictAlgorithm.replace);
  Future<void> saveSpaces(List<Map<String,dynamic>> rows, Map<String,String> levels) async {
    final b=db.batch();
    for(final r in rows){
      final levelId='${r['level']}';
      b.insert('spaces', {'id':'${r['id']}', 'name':'${r['name']}', 'level_name':levels[levelId] ?? ''}, conflictAlgorithm:ConflictAlgorithm.replace);
    }
    await b.commit(noResult:true);
  }
  Future<void> saveRemoteIssue(Map<String,dynamic> row) async {
    // لا نستبدل تعديلاً محلياً لم تتم مزامنته بعد.
    final id='${row['id']}';
    final existing=await db.query('issues',where:'server_id=?',whereArgs:[id],limit:1);
    if(existing.isNotEmpty) return;
    final pendingRow=await db.query('issues',where:'local_id=? AND sync_state IN (?,?)',whereArgs:[id,'pending','photo_pending'],limit:1);
    if(pendingRow.isNotEmpty) return;
    await db.insert('issues', {
      'local_id':id, 'server_id':id, 'space_id':'${row['space']}',
      'title':'${row['title'] ?? ''}', 'description':'${row['description'] ?? ''}',
      'priority':'${row['priority'] ?? 'MEDIUM'}', 'status':'${row['status'] ?? 'OPEN'}',
      'due_date':row['due_date'], 'photo_path':null,
      'sync_state':'synced', 'photo_sync_state':'none', 'created_at':'${row['created_at'] ?? DateTime.now().toIso8601String()}'
    },conflictAlgorithm:ConflictAlgorithm.replace);
  }
  Future<void> markCreated(String localId,String serverId,bool hasPhoto) => db.update('issues', {'server_id':serverId,'sync_state':hasPhoto?'photo_pending':'synced','photo_sync_state':hasPhoto?'pending':'none'},where:'local_id=?',whereArgs:[localId]);
  Future<void> markPhotoSynced(String localId) => db.update('issues', {'sync_state':'synced','photo_sync_state':'synced'},where:'local_id=?',whereArgs:[localId]);
  Future<List<Map<String,dynamic>>> pending() => db.query('issues',where:"sync_state IN ('pending','photo_pending')",orderBy:'created_at ASC');
}

class Api {
  static final Api instance=Api._(); Api._();
  late Dio dio;
  String base='http://10.0.2.2:8000';
  Future<void> configure() async {
    final prefs=await SharedPreferences.getInstance(); base=(prefs.getString('api_base') ?? base).replaceFirst(RegExp(r'/+$'), '');
    dio=Dio(BaseOptions(baseUrl:base, connectTimeout:const Duration(seconds:12), receiveTimeout:const Duration(seconds:20)));
    dio.interceptors.add(InterceptorsWrapper(onRequest:(o,h) async {
      final p=await SharedPreferences.getInstance(); final token=p.getString('access');
      if(token!=null) o.headers['Authorization']='Bearer $token'; h.next(o);
    }, onError:(e,h) async {
      if(e.response?.statusCode==401){ final p=await SharedPreferences.getInstance(); final refresh=p.getString('refresh');
        if(refresh!=null){ try { final r=await Dio().post('$base/api/auth/token/refresh/',data:{'refresh':refresh}); await p.setString('access',r.data['access']); e.requestOptions.headers['Authorization']='Bearer ${r.data['access']}'; final retry=await dio.fetch(e.requestOptions); return h.resolve(retry); } catch (_) {} }
      } h.next(e);
    }));
  }
  Future<void> login(String email,String password) async {
    final r=await dio.post('/api/auth/token/',data:{'email':email,'password':password});
    final p=await SharedPreferences.getInstance(); await p.setString('access',r.data['access']); await p.setString('refresh',r.data['refresh']);
  }
  Future<List<Map<String,dynamic>>> getList(String endpoint) async {
    final all=<Map<String,dynamic>>[];
    dynamic next=endpoint;
    while(next!=null) {
      final response=await dio.get(next.toString());
      final data=response.data;
      if(data is List) {
        all.addAll(data.cast<Map>().map((e)=>Map<String,dynamic>.from(e)));
        next=null;
      } else if(data is Map) {
        final results=(data['results'] as List? ?? []);
        all.addAll(results.cast<Map>().map((e)=>Map<String,dynamic>.from(e)));
        next=data['next'];
      } else { next=null; }
    }
    return all;
  }
  Future<void> sync() async {
    final status=await Connectivity().checkConnectivity(); if(status.contains(ConnectivityResult.none)) return;
    // نجلب أسماء الطوابق والمساحات لعرض موقع كل ملاحظة بشكل مفهوم.
    final levels=await getList('/api/levels/');
    final levelNames={for(final l in levels) '${l['id']}':'${l['name'] ?? ''}'};
    final spaces=await getList('/api/spaces/');
    await LocalStore.instance.saveSpaces(spaces,levelNames);
    for(final row in await LocalStore.instance.pending()){
      try {
        var sid=row['server_id']?.toString();
        // نسجل رقم الخادم فور إنشاء الملاحظة حتى لا ننشئ نسخة مكررة إذا فشل رفع الصورة.
        if(row['sync_state']=='pending'){
          final payload={'space':row['space_id'],'title':row['title'],'description':row['description'] ?? '',
            'priority':row['priority'],'status':row['status'],'due_date':row['due_date']};
          final created=await dio.post('/api/issues/',data:payload);
          sid='${created.data['id']}';
          await LocalStore.instance.markCreated(row['local_id'],sid,row['photo_path']!=null);
        }
        final photo=row['photo_path'];
        if(photo!=null && row['photo_sync_state']!='synced'){
          if(!File(photo).existsSync()) throw Exception('الصورة المحلية غير موجودة');
          await dio.post('/api/photos/',data:FormData.fromMap({'issue':sid,'image':await MultipartFile.fromFile(photo,filename:p.basename(photo))}));
          await LocalStore.instance.markPhotoSynced(row['local_id']);
        }
      } catch (_) { /* تبقى العملية محلياً لإعادة المحاولة لاحقاً دون تكرار الملاحظة */ }
    }
    // نسحب الملاحظات المنشورة على الخادم لتظهر أيضاً على هذا الهاتف.
    try {
      final remote=await getList('/api/issues/');
      for(final item in remote){await LocalStore.instance.saveRemoteIssue(item);}
    } catch (_) { /* يظل العرض المحلي متاحاً عند تعذر الاتصال */ }
  }
}

class Gate extends StatefulWidget { const Gate({super.key}); @override State<Gate> createState()=>_GateState(); }
class _GateState extends State<Gate> {
  bool ready=false,logged=false;
  @override void initState(){super.initState(); _start();}
  Future<void> _start() async { await Api.instance.configure(); final p=await SharedPreferences.getInstance(); logged=p.getString('access')!=null; if(mounted)setState(()=>ready=true); }
  @override Widget build(BuildContext context)=>!ready?const Scaffold(body:Center(child:CircularProgressIndicator())):logged?const IssuesPage():LoginPage(onLogin:(){setState(()=>logged=true);});
}

class LoginPage extends StatefulWidget { final VoidCallback onLogin; const LoginPage({super.key,required this.onLogin}); @override State<LoginPage> createState()=>_LoginPageState(); }
class _LoginPageState extends State<LoginPage>{ final email=TextEditingController(),pass=TextEditingController(),url=TextEditingController(); bool busy=false,showUrl=true; String? error;
 @override void initState(){super.initState(); SharedPreferences.getInstance().then((p){url.text=p.getString('api_base')??'http://10.0.2.2:8000';});}
 Future<void> submit() async {setState((){busy=true;error=null;}); try {final prefs=await SharedPreferences.getInstance(); if(url.text.trim().isNotEmpty){await prefs.setString('api_base',url.text.trim());} await Api.instance.configure(); await Api.instance.login(email.text.trim(),pass.text); await Api.instance.sync(); widget.onLogin();}catch(e){setState(()=>error='تعذر تسجيل الدخول. تحقق من عنوان الخادم وبيانات الحساب.');}finally{if(mounted)setState(()=>busy=false);}}
 @override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
  Container(height:90,width:90,decoration:BoxDecoration(color:brandNavy,borderRadius:BorderRadius.circular(26)),child:const Icon(Icons.apartment_rounded,color:brandGold,size:48)),const SizedBox(height:24),const Text('ALIOUA BTP',style:TextStyle(fontSize:28,fontWeight:FontWeight.w900,color:brandNavy)),const Text('متابعة الورش أصبحت أسهل',style:TextStyle(color:Colors.blueGrey,fontSize:16)),const SizedBox(height:32),TextField(controller:email,keyboardType:TextInputType.emailAddress,decoration:const InputDecoration(labelText:'البريد الإلكتروني',prefixIcon:Icon(Icons.mail_outline))),const SizedBox(height:14),TextField(controller:pass,obscureText:true,decoration:const InputDecoration(labelText:'كلمة المرور',prefixIcon:Icon(Icons.lock_outline))),const SizedBox(height:10),Align(alignment:Alignment.centerLeft,child:TextButton(onPressed:()=>setState(()=>showUrl=!showUrl),child:const Text('إعداد عنوان الخادم'))),if(showUrl)Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[TextField(controller:url,keyboardType:TextInputType.url,decoration:const InputDecoration(labelText:'عنوان خادم الشركة (API)',hintText:'http://192.168.1.10:8000')),const SizedBox(height:5),const Text('على الهاتف الحقيقي أدخل عنوان IP للحاسوب الذي يشغّل الخادم، والهاتف والحاسوب على شبكة Wi‑Fi نفسها.',style:TextStyle(fontSize:12,color:Colors.blueGrey)),]),if(error!=null)Padding(padding:const EdgeInsets.all(8),child:Text(error!,style:const TextStyle(color:Colors.red))),const SizedBox(height:12),ElevatedButton(onPressed:busy?null:submit,child:busy?const CircularProgressIndicator(color:Colors.white):const Text('تسجيل الدخول')),const SizedBox(height:14),const Text('يعمل التطبيق دون اتصال لحفظ الملاحظات، ثم يزامنها عند عودة الشبكة.',textAlign:TextAlign.center,style:TextStyle(color:Colors.blueGrey))])))));
}

class IssuesPage extends StatefulWidget { const IssuesPage({super.key}); @override State<IssuesPage> createState()=>_IssuesPageState(); }
class _IssuesPageState extends State<IssuesPage>{List<Map<String,dynamic>> rows=[];bool loading=false;String? message;StreamSubscription<List<ConnectivityResult>>? connectionSub;
 @override void initState(){super.initState();_load();connectionSub=Connectivity().onConnectivityChanged.listen((states){if(!states.contains(ConnectivityResult.none)){_load();}});}
 @override void dispose(){connectionSub?.cancel();super.dispose();}
 Future<void> _load() async {setState(()=>loading=true);try{await Api.instance.sync();}catch(_){} rows=await LocalStore.instance.issues();if(mounted)setState(()=>loading=false);}
 Future<void> _add() async {final changed=await Navigator.push(context,MaterialPageRoute(builder:(_)=>const NewIssuePage()));if(changed==true)_load();}
 Future<void> _logout() async {final p=await SharedPreferences.getInstance();await p.remove('access');await p.remove('refresh');if(mounted)Navigator.pushAndRemoveUntil(context,MaterialPageRoute(builder:(_)=>Gate()),(_)=>false);}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('ملاحظات الورش',style:TextStyle(fontWeight:FontWeight.bold)),actions:[IconButton(onPressed:_load,icon:const Icon(Icons.sync)),IconButton(onPressed:_logout,icon:const Icon(Icons.logout))]),floatingActionButton:FloatingActionButton.extended(onPressed:_add,backgroundColor:brandTeal,foregroundColor:Colors.white,icon:const Icon(Icons.add),label:const Text('ملاحظة جديدة')),body:RefreshIndicator(onRefresh:_load,child:ListView(padding:const EdgeInsets.fromLTRB(16,8,16,90),children:[Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(gradient:const LinearGradient(colors:[brandNavy,Color(0xFF246A83)]),borderRadius:BorderRadius.circular(22)),child:Row(children:[const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('ALIOUA BTP',style:TextStyle(color:Colors.white70)),SizedBox(height:5),Text('كل ملاحظة تقرّبنا من إنجاز أفضل',style:TextStyle(color:Colors.white,fontWeight:FontWeight.bold,fontSize:17))])),Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:brandGold,borderRadius:BorderRadius.circular(16)),child:const Icon(Icons.construction,color:brandNavy,size:30))])),const SizedBox(height:20),Row(children:[const Text('آخر الملاحظات',style:TextStyle(fontWeight:FontWeight.bold,fontSize:19,color:brandNavy)),const Spacer(),Text('${rows.length} سجل',style:const TextStyle(color:Colors.blueGrey))]),const SizedBox(height:10),if(loading&&rows.isEmpty)const Center(child:CircularProgressIndicator()),if(rows.isEmpty&&!loading)const Padding(padding:EdgeInsets.all(30),child:Text('لا توجد ملاحظات بعد. اضغط «ملاحظة جديدة» للبدء.',textAlign:TextAlign.center,style:TextStyle(color:Colors.blueGrey))),...rows.map((r)=>IssueCard(row:r))])));
}

class IssueCard extends StatelessWidget{final Map<String,dynamic> row;const IssueCard({super.key,required this.row});@override Widget build(BuildContext context){final synced=row['sync_state']=='synced';final priority=row['priority'];return Card(color:Colors.white,elevation:0,margin:const EdgeInsets.only(bottom:10),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(17)),child:Padding(padding:const EdgeInsets.all(14),child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[Container(width:44,height:44,decoration:BoxDecoration(color:priority=='CRITICAL'?const Color(0xFFFFE5E2):const Color(0xFFE2F5F3),borderRadius:BorderRadius.circular(13)),child:Icon(Icons.assignment_late_outlined,color:priority=='CRITICAL'?Colors.deepOrange:brandTeal)),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('${row['title']}',style:const TextStyle(fontWeight:FontWeight.bold,color:brandNavy,fontSize:16)),const SizedBox(height:5),Text('${row['description']??''}',maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.blueGrey)),const SizedBox(height:8),Row(children:[Text('الأولوية: ${priority??'MEDIUM'}',style:const TextStyle(fontSize:11,color:Colors.blueGrey)),const Spacer(),Icon(synced?Icons.cloud_done:Icons.cloud_upload_outlined,size:15,color:synced?brandTeal:brandGold),const SizedBox(width:4),Text(synced?'تمت المزامنة':'بانتظار المزامنة',style:TextStyle(fontSize:11,color:synced?brandTeal:Colors.deepOrange))])])),if(row['photo_path']!=null)Padding(padding:const EdgeInsets.only(left:8),child:ClipRRect(borderRadius:BorderRadius.circular(10),child:Image.file(File(row['photo_path']),width:54,height:54,fit:BoxFit.cover,errorBuilder:(_,__,___)=>const SizedBox())))])));}}

class NewIssuePage extends StatefulWidget{const NewIssuePage({super.key});@override State<NewIssuePage> createState()=>_NewIssuePageState();}
class _NewIssuePageState extends State<NewIssuePage>{final title=TextEditingController(),desc=TextEditingController();String priority='MEDIUM';String? spaceId,photo;DateTime? due;List<Map<String,dynamic>> spaces=[];bool saving=false;
 @override void initState(){super.initState();LocalStore.instance.spaces().then((s){if(mounted)setState(()=>spaces=s);});}
 Future<void> takePhoto() async {final x=await ImagePicker().pickImage(source:ImageSource.camera,imageQuality:72,maxWidth:1600);if(x!=null){final dir=await getApplicationDocumentsDirectory();final saved=await File(x.path).copy(p.join(dir.path,'issue_${DateTime.now().microsecondsSinceEpoch}.jpg'));if(mounted)setState(()=>photo=saved.path);}}
 Future<void> save() async {if(title.text.trim().isEmpty||spaceId==null){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('أدخل عنوان الملاحظة واختر المساحة.')));return;}setState(()=>saving=true);final id=const Uuid().v4();await LocalStore.instance.saveIssue({'local_id':id,'space_id':spaceId,'title':title.text.trim(),'description':desc.text.trim(),'priority':priority,'status':'OPEN','due_date':due==null?null:DateFormat('yyyy-MM-dd').format(due!), 'photo_path':photo,'sync_state':'pending','photo_sync_state':photo==null?'none':'pending','created_at':DateTime.now().toIso8601String()});try{await Api.instance.sync();}catch(_){}if(mounted)Navigator.pop(context,true);}
 @override void dispose(){title.dispose();desc.dispose();super.dispose();}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('إنشاء ملاحظة')),body:ListView(padding:const EdgeInsets.all(16),children:[TextField(controller:title,decoration:const InputDecoration(labelText:'عنوان الملاحظة *')),const SizedBox(height:12),TextField(controller:desc,maxLines:4,decoration:const InputDecoration(labelText:'الوصف',alignLabelWithHint:true)),const SizedBox(height:12),DropdownButtonFormField<String>(value:spaceId,decoration:const InputDecoration(labelText:'المساحة *'),items:spaces.map((s)=>DropdownMenuItem(value:'${s['id']}',child:Text('${s['name']} ${s['level_name']??''}'))).toList(),onChanged:(v)=>setState(()=>spaceId=v)),const SizedBox(height:12),DropdownButtonFormField<String>(value:priority,decoration:const InputDecoration(labelText:'الأولوية'),items:const [DropdownMenuItem(value:'LOW',child:Text('منخفضة')),DropdownMenuItem(value:'MEDIUM',child:Text('متوسطة')),DropdownMenuItem(value:'HIGH',child:Text('مرتفعة')),DropdownMenuItem(value:'CRITICAL',child:Text('حرجة'))],onChanged:(v)=>setState(()=>priority=v??'MEDIUM')),const SizedBox(height:12),OutlinedButton.icon(onPressed:()async{final d=await showDatePicker(context:context,firstDate:DateTime.now(),lastDate:DateTime.now().add(const Duration(days:3650)),initialDate:DateTime.now());if(d!=null)setState(()=>due=d);},icon:const Icon(Icons.event),label:Text(due==null?'تحديد موعد (اختياري)':DateFormat('yyyy-MM-dd').format(due!))),const SizedBox(height:12),if(photo!=null)ClipRRect(borderRadius:BorderRadius.circular(16),child:Image.file(File(photo!),height:180,fit:BoxFit.cover)),OutlinedButton.icon(onPressed:takePhoto,icon:const Icon(Icons.camera_alt_outlined),label:Text(photo==null?'التقاط صورة':'تغيير الصورة')),const SizedBox(height:20),ElevatedButton(onPressed:saving?null:save,child:saving?const CircularProgressIndicator(color:Colors.white):const Text('حفظ الملاحظة'))]));}
